# import selenium
from selenium import webdriver
from selenium.webdriver.common.by import By
import time
from selenium.webdriver.chrome.options import Options #Use your own web browser
from user_agent import generate_user_agent, generate_navigator
import json

DRIVERPATH ="./chromedriver"
options = Options()
driver=webdriver.Chrome(executable_path=DRIVERPATH)
storedComponents=[]
geoJson={
  "type": "FeatureCollection",
  "features": [
  ]
}
time.sleep(5)
driver.get('https://www.google.com/search?q=cafe%20bandung&rlz=1C5GCEM_enID994ID994&tbm=lcl&sxsrf=ALiCzsZ-WzPoIQvVxJ7oFzjrwhblTcM3rg%3A1662880895598&ei=f4wdY9aNJIuhz7sPw7qw2AY&oq=cafe+bandung&gs_l=psy-ab.3...0.0.0.4359.0.0.0.0.0.0.0.0..0.0....0...1c..64.psy-ab..0.0.0....0.4gSqc_UBM8Y&tbs=lrf:!1m4!1u3!2m2!3m1!1e1!1m4!1u2!2m2!2m1!1e1!1m4!1u1!2m2!1m1!1e1!1m4!1u1!2m2!1m1!1e2!2m1!1e2!2m1!1e1!2m1!1e3!3sIAE,lf:1,lf_ui:9&rlst=f#rlfi=hd:;si:;mv:[[-6.834520643697811,107.73060085686151],[-6.938137818064301,107.55550625236933],null,[-6.886332059760476,107.64305355461542],13]')
time.sleep(20)
def scrapper():
  targetedElement=driver.find_elements(By.CSS_SELECTOR,'[jsname="GZq3Ke"]')
  countItem=0
  for x in targetedElement:
      countItem=countItem+1
      objt={
        "type": "Feature",
        "properties": {
          "id":'',
          "name":'',
          "popularTimes":[]
        },
        "geometry": {
          "type": "Point",
          "coordinates": []
        }
      }
      xid=x.get_attribute("id")
      try:
        xmark=driver.find_element(By.CSS_SELECTOR,'#'+xid+' > div.rllt__mi')
        xa=driver.find_element(By.CSS_SELECTOR,'#'+xid+' > div > div.VkpGBb > div > a.vwVdIc.wzN8Ac.rllt__link.a-no-hover-decoration')
        time.sleep(2)
        xa.click()
        names=driver.find_element(By.XPATH,'//*[@id="akp_tsuid_9"]/div/div[1]/div/div/block-component/div/div[1]/div/div/div/div[1]/div/div/div[1]/div/div[1]/div/div[2]/h2').text
        pdaysbtn=driver.find_elements(By.CLASS_NAME,'Bx6Bi')
        for dbtn in pdaysbtn:
          print('dbtn')
          dbtn.click()
          time.sleep(1)
          xbars=driver.find_elements(By.CLASS_NAME,'cwiwob')
          dname=dbtn.get_attribute("aria-label")
          popularTimes={}
          for idx,bar in enumerate(xbars):
            print('xbars')
            print(idx)
            hname=driver.find_elements(By.CLASS_NAME,'wYzX9b')[idx].get_attribute("aria-label")
            print(hname)
            popularTimes[hname]=float(bar.value_of_css_property('height').replace('px',''))
          objt['properties'][dname]=popularTimes
          print(objt['properties'][dname])
        # pdays=['Monday','Tuesday','Wednesday','Thrusday','Friday','Saturday','Sunday']
        # phours=[6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23]
        objt['properties']['id']=xid
        objt['properties']['name']=names
        objt['properties']['popularTimes']=popularTimes
        objt['geometry']['coordinates']=[float(xmark.get_attribute('data-lng')),float(xmark.get_attribute('data-lat'))]
        time.sleep(3)
        geoJson['features'].append(objt)
      except:
        print('')
scrapper()
pageCount=1
nextButton=driver.find_element(By.ID,'pnnext')
while pageCount<16:
  time.sleep(2)
  try:
    nextButton=driver.find_element(By.ID,'pnnext')
    nextButton.click()
    time.sleep(5)
    scrapper()
  finally:
    pageCount=pageCount+1
# Serializing json
json_object = json.dumps(geoJson, indent=4)
# Writing to sample.json
with open("result2.geojson", "w") as outfile:
    outfile.write(json_object)
# print(geoJson)


# driver.quit()