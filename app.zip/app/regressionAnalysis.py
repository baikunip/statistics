import pandas as pd
import numpy as np

df2=pd.read_excel('./center_data/dataSekunder.xlsx')
print(df2)
df=pd.read_csv('./clusteredData.csv')
