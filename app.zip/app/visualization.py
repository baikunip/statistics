# Run this app with `python app.py` and
# visit http://127.0.0.1:8050/ in your web browser.

from dash import Dash,dcc,html
from dash.dependencies import Input, Output
from dash.exceptions import PreventUpdate
import plotly.express as px
import plotly.graph_objects as go
import pandas as pd
from sklearn.cluster import KMeans
from sklearn.preprocessing import MinMaxScaler
import numpy as np
import json

app = Dash(__name__)

# assume you have a "long-form" data frame
# see https://plotly.com/python/px-arguments/ for more options
df = pd.read_csv('jabar_housing.csv')
# jarak=df['jarak'].tolist()
df=df.fillna(0)
luas_lahan=df['luas_lahan'].tolist()
df['total_luas']=df['luas_lahan']+df['luas_bangunan']
df['harga_fix']=df['harga']/df['total_luas']
harga=df['harga_fix'].tolist()
outliers=df.index[df['harga_fix']>40000000].tolist()
outliers_luas=df.index[df['total_luas']>10000].tolist()
df=df.drop(outliers)
df=df.drop(outliers_luas)
# Cluster Analysis
X=df.drop(['lon','lat','link','category','name','daerah'],axis=1).set_index('id')
XDesc=df.set_index('id').drop(['harga','jumlah_kamar','jumlah_kamar_mandi','luas_garasi','luas_bangunan','luas_lahan'],axis=1)

scaler = MinMaxScaler()
scaler.fit(X)
X=scaler.transform(X)
inertia = []
for i in range(1,11):
    kmeans = KMeans(
        n_clusters=i, init="k-means++",
        n_init=10,
        tol=1e-04, random_state=42
    )
    kmeans.fit(X)
    inertia.append(kmeans.inertia_)
    
kmeans = KMeans(
        n_clusters=4, init="k-means++",
        n_init=10,
        tol=1e-04, random_state=42
)
kmeans.fit(X)
clusters=pd.DataFrame(X,columns=df.set_index('id').drop(['lon','lat','link','category','name','daerah'],axis=1).columns)
clusters['label']=kmeans.labels_
df['label']=kmeans.labels_
clusteredGeoJSON={
    "type": "FeatureCollection",
    "features": []
}
headerList=list(df.columns.values)
headerList.remove('lon')
headerList.remove('lat')
for index, row in df.iterrows():
    prop={}
    for column in headerList:
        prop[column]=row[column]
    feature={
         "type": "Feature","properties":prop,
         "geometry": {
                "type": "Point",
                "coordinates": [
                    # -7.029438610736,
                    # 107.53866639328
                    row['lon'],row['lat']
                ]
            }
    }
    clusteredGeoJSON['features'].append(feature)

# print(clusteredGeoJSON)
# json_object = json.dumps(clusteredGeoJSON, indent=4)
#     # Writing to sample.json
# with open("clusteredResult2.geojson", "w") as outfile:
#     outfile.write(json_object)
clusters['label']=clusters['label'].astype('string')
df['label']=df['label'].astype('string')
inputLabel=[]
for key in list(clusters.columns.values):
    inputLabel.append({'label':key,'value':key})
fig_elbow = go.Figure(data=go.Scatter(x=np.arange(1,11),y=inertia,line_color='red'))
fig_elbow.update_layout(title="Inertia vs Cluster Number",xaxis=dict(range=[0,11],title="Cluster Number"),
                  yaxis={'title':'Inertia'},
                 annotations=[
        dict(
            x=4,
            y=inertia[3],
            xref="x",
            yref="y",
            text="Elbow!",
            showarrow=True,
            arrowhead=7,
            ax=20,
            ay=-50
        )
    ])
fig_cluster=px.scatter_matrix(clusters,width=1800, height=2200,color='label')
# end of cluster analysis
fig = px.scatter(clusters, x="total_luas", y="harga_fix",color="label")
fig.update_layout(
    autosize=False,
    width=400,
    height=1000)
scatter_matrix= px.scatter_matrix(df.drop(["id","name","link","lon","lat","category"],axis=1),width=1500, height=2200)
histo=px.histogram(df,x='daerah')
scatter_3d=px.scatter_3d(clusters,x="total_luas", y="harga_fix",color='label')
clusteredHistogram=px.histogram(df,x='daerah',color='label',barmode='group',text_auto='.2s')
clusteredPie=px.pie(df,names='daerah',values='label')
app.layout = html.Div(children=[
    html.H1(children='Hello Dash'),
    # html.Div(children=[dash_table.DataTable(df.to_dict('records'), [{"name": i, "id": i} for i in df.columns])]
    # ),
    html.Div(children=[
        html.H2(children='Y Values: '),
        dcc.Dropdown(options=inputLabel, value='harga_fix', id='y-dropdown'),
    ]),
    html.Div(children=[
        html.H2(children='X Values: '),
        dcc.Dropdown(options=inputLabel, value='total_luas', id='x-dropdown'),
    ]),
    html.Div(children='''
        Dash: A web application framework for your data.
    '''),
    dcc.Graph(
        id='example-graph',
        figure=fig,
        style={
            'width':'60vw',
            'height':'90vh'
        }
    ),
    dcc.Graph(
        id='cluster-graph',
        figure=fig_elbow,
        style={
            'width':'60vw',
            'height':'90vh'
        }
    ),
    dcc.Graph(
        id='clustered-histogram',
        figure=clusteredHistogram
    ),
    dcc.Graph(
        id='histo-1',
        figure=fig_cluster,
        style={
            'width':'60vw',
            'height':'90vh'
        }
    )
])
@app.callback(
    Output(component_id='example-graph',component_property='figure'),
    Input(component_id='y-dropdown',component_property='value'),
    Input(component_id='x-dropdown',component_property='value')
)
def update_input(y_change,x_change):
    return px.scatter(clusters, x=x_change, y=y_change,color="label")
        
if __name__ == '__main__':
    app.run_server(debug=True)
